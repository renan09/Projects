-- Get a list of tables and views in the current database
DELETE FROM django_migrations WHERE app = 'myblogapp'
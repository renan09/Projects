from django.apps import AppConfig


class MyblogappConfig(AppConfig):
    name = 'myblogapp'
